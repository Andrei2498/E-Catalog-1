create function NumarAbsenteTotale(p_id_elev int)
return int as
    v_rezultat int := 0;
begin
    select count(*) into v_rezultat from ACTIVITATE where id_elev = p_id_elev and nota is null;
    
    return v_rezultat;
end;
/

