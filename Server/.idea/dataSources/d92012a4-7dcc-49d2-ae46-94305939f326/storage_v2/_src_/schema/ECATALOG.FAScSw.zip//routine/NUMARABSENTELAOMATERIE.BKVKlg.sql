create function NumarAbsenteLaOMaterie(p_id_materie int, p_id_elev int)
return int as
    v_rezultat int := 0;
begin
    select count(*) into v_rezultat from ACTIVITATE where id_elev = p_id_elev and nota is null and id_materie = p_id_materie;
    
    return v_rezultat;
end;
/

