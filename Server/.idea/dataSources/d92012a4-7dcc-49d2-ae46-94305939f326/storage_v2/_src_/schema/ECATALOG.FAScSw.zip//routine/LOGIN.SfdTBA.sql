create function Login(p_sir_car varchar2)
return varchar2 as
  v_rezultat varchar2(1000) := '';
  v_username varchar2(100) := '';
  v_password varchar2(100) := '';
  v_index int := 1;
  v_index1 int := 1;
  v_curent_char varchar2(1) := 'Z';
  v_nume varchar2(100) := '';
  v_prenume varchar2(100) := '';
  v_id int := 0;
begin
  while ( v_index <= length(p_sir_car) and v_curent_char != ' ' ) loop
    v_curent_char := substr(p_sir_car,v_index,1);
    v_index := v_index + 1;
  end loop;
  v_username := substr(p_sir_car,1,v_index - 2);
  v_password := substr(p_sir_car,v_index);
  
  select count(*) into v_index from ACCOUNTS where NUME_CONT like v_username and PAROLA like v_password;
  select id_persoana into v_id from accounts where nume_cont like v_username and parola like v_password;
  if(v_index = 1 ) then
    if (substr(v_username,1,2) = 'E.') then
      v_index := 3;
      v_curent_char := 'Z';
      v_index1 := instr(substr(v_username,3),'.');
      v_nume := upper(substr(v_username,3,1)) || substr(v_username,4,v_index1 - 2);
      v_username := substr(v_username,v_index1 + v_index);
      v_index := instr(v_username,'.');
      if(v_index > 0) then
        v_prenume := upper(substr(v_username,1,1)) || substr(v_username,2,v_index - 2) || ' '
          || upper(substr(v_username,v_index + 1,1)) || substr(v_username,v_index + 2);
      else
        v_prenume := upper(substr(v_username,1,1)) || substr(v_username,2,length(v_username) - 1);
      end if;
      select id || ' ' || nume || ' ' || prenume || ' ' || nr_matricol || ' '|| profil || 
        ' ' || clasa into v_rezultat from ELEVI where nume like v_nume and prenume like v_prenume and id = v_id;
    elsif (substr(v_username,1,2) = 'P.') then
      v_index := 3;
      v_curent_char := 'Z';
      v_index1 := instr(substr(v_username,3),'.');
      v_nume := upper(substr(v_username,3,1)) || substr(v_username,4,v_index1 - 2);
      v_username := substr(v_username,v_index1 + v_index);
      v_index := instr(v_username,'.');
      if(v_index > 0) then
        v_prenume := upper(substr(v_username,1,1)) || substr(v_username,2,v_index - 2) || ' '
          || upper(substr(v_username,v_index + 1,1)) || substr(v_username,v_index + 2);
      else
        v_prenume := upper(substr(v_username,1,1)) || substr(v_username,2);
      end if;
      select id || ' ' || nume || ' ' || prenume || ' '  || email 
        into v_rezultat from profesori where nume like v_nume and prenume like v_prenume and id = v_id;
    else 
      v_index := 4;
      v_curent_char := 'Z';
      v_index1 := instr(substr(v_username,4),'.');
      v_nume := upper(substr(v_username,4,1)) || substr(v_username,5,v_index1 - 2);
      v_username := substr(v_username,v_index1 + v_index );
      v_index := instr(v_username,'.');
      if(v_index > 0) then
        v_prenume := upper(substr(v_username,1,1)) || substr(v_username,2,v_index - 2) || ' '
          || upper(substr(v_username,v_index + 1,1)) || substr(v_username,v_index + 2);
      else
        v_prenume := upper(substr(v_username,1,1)) || substr(v_username,2);
      end if;
      select id || ' ' || nume || ' ' || prenume || ' '  || id_elev
        into v_rezultat from parinti where nume like v_nume and prenume like v_prenume and id = v_id;
    end if;
  ELSIF (v_index = 0 ) then
    v_rezultat := 'Contul introdus este incorect.';
  else
    v_rezultat := 'Ceva nu a funtionat corect. Va rugam reincercati.';
  end if;
  return v_rezultat;
end;
/

