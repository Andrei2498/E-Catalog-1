create function MedieMaterie(p_nume_materie varchar2, p_id_elev int)
return number as
    v_clasa int := 0;
    v_profile varchar2(10) := '';
    v_rezultat number;
    v_id_materie int := 0;
    v_try int := 0;
    v_teza int := 0;
    v_temporar number;
begin
    select clasa,profil into v_clasa,v_profile from elevi where id = p_id_elev;
    select id into v_id_materie from materii where nume_materie like p_nume_materie and clasa = v_clasa and profil like v_profile;
    
    select count(*) into v_try from teze where id_elev = p_id_elev and id_materie = v_id_materie;
    
    if(v_try > 0) then
      select avg(nota) into v_temporar from activitate where ID_ELEV = p_id_elev and id_materie = v_id_materie
        and nota is not null;
      select nota_teza into v_teza from teze where id_materie = v_id_materie and ID_ELEV = p_id_elev;
    
      v_rezultat := ((v_temporar) * 3 + v_teza) / 4;
    
      return v_rezultat;
    else 
      select avg(nota) into v_rezultat from activitate where ID_ELEV = p_id_elev and id_materie = v_id_materie
        and nota is not null;
      return v_rezultat;
    end if;
    
end;
/

